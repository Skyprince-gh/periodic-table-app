module.exports = {

"[externals]/next/dist/compiled/next-server/app-page.runtime.dev.js [external] (next/dist/compiled/next-server/app-page.runtime.dev.js, cjs)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
const mod = __turbopack_external_require__("next/dist/compiled/next-server/app-page.runtime.dev.js", () => require("next/dist/compiled/next-server/app-page.runtime.dev.js"));

module.exports = mod;
}}),
"[project]/hooks/useElementData.ts [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "useElementData": (()=>useElementData)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
'use client';
;
const elementData = [
    {
        image: 'https://unsplash.com/random',
        name: 'Hydrogen',
        symbol: 'H',
        atomicNumber: 1,
        atomicMass: 1.008,
        category: 'Nonmetal',
        period: 1,
        group: 1
    },
    {
        image: '/',
        name: 'Helium',
        symbol: 'He',
        atomicNumber: 2,
        atomicMass: 4.003,
        category: 'Noble Gas',
        period: 1,
        group: 18
    },
    {
        image: '/',
        name: 'Lithium',
        symbol: 'Li',
        atomicNumber: 3,
        atomicMass: 6.941,
        category: 'Alkali Metal',
        period: 2,
        group: 1
    },
    {
        image: '/',
        name: 'Beryllium',
        symbol: 'Be',
        atomicNumber: 4,
        atomicMass: 9.012,
        category: 'Alkaline Earth Metal',
        period: 2,
        group: 2
    },
    {
        image: '/',
        name: 'Boron',
        symbol: 'B',
        atomicNumber: 5,
        atomicMass: 10.811,
        category: 'Metalloid',
        period: 2,
        group: 13
    },
    {
        image: '/',
        name: 'Carbon',
        symbol: 'C',
        atomicNumber: 6,
        atomicMass: 12.011,
        category: 'Nonmetal',
        period: 2,
        group: 14
    },
    {
        image: '/',
        name: 'Nitrogen',
        symbol: 'N',
        atomicNumber: 7,
        atomicMass: 14.007,
        category: 'Nonmetal',
        period: 2,
        group: 15
    },
    {
        image: '/',
        name: 'Oxygen',
        symbol: 'O',
        atomicNumber: 8,
        atomicMass: 15.999,
        category: 'Nonmetal',
        period: 2,
        group: 16
    },
    {
        image: '/',
        name: 'Fluorine',
        symbol: 'F',
        atomicNumber: 9,
        atomicMass: 18.998,
        category: 'Halogen',
        period: 2,
        group: 17
    },
    {
        image: '/',
        name: 'Neon',
        symbol: 'Ne',
        atomicNumber: 10,
        atomicMass: 20.18,
        category: 'Noble Gas',
        period: 2,
        group: 18
    },
    {
        image: '/',
        name: 'Sodium',
        symbol: 'Na',
        atomicNumber: 11,
        atomicMass: 22.99,
        category: 'Alkali Metal',
        period: 3,
        group: 1
    },
    {
        image: '/',
        name: 'Magnesium',
        symbol: 'Mg',
        atomicNumber: 12,
        atomicMass: 24.305,
        category: 'Alkaline Earth Metal',
        period: 3,
        group: 2
    },
    {
        image: '/',
        name: 'Aluminum',
        symbol: 'Al',
        atomicNumber: 13,
        atomicMass: 26.982,
        category: 'Post-Transition Metal',
        period: 3,
        group: 13
    },
    {
        image: '/',
        name: 'Silicon',
        symbol: 'Si',
        atomicNumber: 14,
        atomicMass: 28.086,
        category: 'Metalloid',
        period: 3,
        group: 14
    },
    {
        image: '/',
        name: 'Phosphorus',
        symbol: 'P',
        atomicNumber: 15,
        atomicMass: 30.974,
        category: 'Nonmetal',
        period: 3,
        group: 15
    },
    {
        image: '/',
        name: 'Sulfur',
        symbol: 'S',
        atomicNumber: 16,
        atomicMass: 32.065,
        category: 'Nonmetal',
        period: 3,
        group: 16
    },
    {
        image: '/',
        name: 'Chlorine',
        symbol: 'Cl',
        atomicNumber: 17,
        atomicMass: 35.453,
        category: 'Halogen',
        period: 3,
        group: 17
    },
    {
        image: '/',
        name: 'Argon',
        symbol: 'Ar',
        atomicNumber: 18,
        atomicMass: 39.948,
        category: 'Noble Gas',
        period: 3,
        group: 18
    },
    {
        image: '/',
        name: 'Potassium',
        symbol: 'K',
        atomicNumber: 19,
        atomicMass: 39.098,
        category: 'Alkali Metal',
        period: 4,
        group: 1
    },
    {
        image: '/',
        name: 'Calcium',
        symbol: 'Ca',
        atomicNumber: 20,
        atomicMass: 40.078,
        category: 'Alkaline Earth Metal',
        period: 4,
        group: 2
    },
    {
        image: '/',
        name: 'Scandium',
        symbol: 'Sc',
        atomicNumber: 21,
        atomicMass: 44.956,
        category: 'Transition Metal',
        period: 4,
        group: 3
    },
    {
        image: '/',
        name: 'Titanium',
        symbol: 'Ti',
        atomicNumber: 22,
        atomicMass: 47.867,
        category: 'Transition Metal',
        period: 4,
        group: 4
    },
    {
        image: '/',
        name: 'Vanadium',
        symbol: 'V',
        atomicNumber: 23,
        atomicMass: 50.942,
        category: 'Transition Metal',
        period: 4,
        group: 5
    },
    {
        image: '/',
        name: 'Chromium',
        symbol: 'Cr',
        atomicNumber: 24,
        atomicMass: 51.996,
        category: 'Transition Metal',
        period: 4,
        group: 6
    },
    {
        image: '/',
        name: 'Manganese',
        symbol: 'Mn',
        atomicNumber: 25,
        atomicMass: 54.938,
        category: 'Transition Metal',
        period: 4,
        group: 7
    },
    {
        image: '/',
        name: 'Iron',
        symbol: 'Fe',
        atomicNumber: 26,
        atomicMass: 55.845,
        category: 'Transition Metal',
        period: 4,
        group: 8
    },
    {
        image: '/',
        name: 'Cobalt',
        symbol: 'Co',
        atomicNumber: 27,
        atomicMass: 58.933,
        category: 'Transition Metal',
        period: 4,
        group: 9
    },
    {
        image: '/',
        name: 'Nickel',
        symbol: 'Ni',
        atomicNumber: 28,
        atomicMass: 58.693,
        category: 'Transition Metal',
        period: 4,
        group: 10
    },
    {
        image: '/',
        name: 'Copper',
        symbol: 'Cu',
        atomicNumber: 29,
        atomicMass: 63.546,
        category: 'Transition Metal',
        period: 4,
        group: 11
    },
    {
        image: '/',
        name: 'Zinc',
        symbol: 'Zn',
        atomicNumber: 30,
        atomicMass: 65.38,
        category: 'Transition Metal',
        period: 4,
        group: 12
    },
    {
        image: '/',
        name: 'Gallium',
        symbol: 'Ga',
        atomicNumber: 31,
        atomicMass: 69.723,
        category: 'Post-Transition Metal',
        period: 4,
        group: 13
    },
    {
        image: '/',
        name: 'Germanium',
        symbol: 'Ge',
        atomicNumber: 32,
        atomicMass: 72.63,
        category: 'Metalloid',
        period: 4,
        group: 14
    },
    {
        image: '/',
        name: 'Arsenic',
        symbol: 'As',
        atomicNumber: 33,
        atomicMass: 74.922,
        category: 'Metalloid',
        period: 4,
        group: 15
    },
    {
        image: '/',
        name: 'Selenium',
        symbol: 'Se',
        atomicNumber: 34,
        atomicMass: 78.971,
        category: 'Nonmetal',
        period: 4,
        group: 16
    },
    {
        image: '/',
        name: 'Bromine',
        symbol: 'Br',
        atomicNumber: 35,
        atomicMass: 79.904,
        category: 'Halogen',
        period: 4,
        group: 17
    },
    {
        image: '/',
        name: 'Krypton',
        symbol: 'Kr',
        atomicNumber: 36,
        atomicMass: 83.798,
        category: 'Noble Gas',
        period: 4,
        group: 18
    },
    {
        image: '/',
        name: 'Rubidium',
        symbol: 'Rb',
        atomicNumber: 37,
        atomicMass: 85.468,
        category: 'Alkali Metal',
        period: 5,
        group: 1
    },
    {
        image: '/',
        name: 'Strontium',
        symbol: 'Sr',
        atomicNumber: 38,
        atomicMass: 87.62,
        category: 'Alkaline Earth Metal',
        period: 5,
        group: 2
    },
    {
        image: '/',
        name: 'Yttrium',
        symbol: 'Y',
        atomicNumber: 39,
        atomicMass: 88.906,
        category: 'Transition Metal',
        period: 5,
        group: 3
    },
    {
        image: '/',
        name: 'Zirconium',
        symbol: 'Zr',
        atomicNumber: 40,
        atomicMass: 91.224,
        category: 'Transition Metal',
        period: 5,
        group: 4
    },
    {
        image: '/',
        name: 'Niobium',
        symbol: 'Nb',
        atomicNumber: 41,
        atomicMass: 92.906,
        category: 'Transition Metal',
        period: 5,
        group: 5
    },
    {
        image: '/',
        name: 'Molybdenum',
        symbol: 'Mo',
        atomicNumber: 42,
        atomicMass: 95.95,
        category: 'Transition Metal',
        period: 5,
        group: 6
    },
    {
        image: '/',
        name: 'Technetium',
        symbol: 'Tc',
        atomicNumber: 43,
        atomicMass: 98,
        category: 'Transition Metal',
        period: 5,
        group: 7
    },
    {
        image: '/',
        name: 'Ruthenium',
        symbol: 'Ru',
        atomicNumber: 44,
        atomicMass: 101.07,
        category: 'Transition Metal',
        period: 5,
        group: 8
    },
    {
        image: '/',
        name: 'Rhodium',
        symbol: 'Rh',
        atomicNumber: 45,
        atomicMass: 102.906,
        category: 'Transition Metal',
        period: 5,
        group: 9
    },
    {
        image: '/',
        name: 'Palladium',
        symbol: 'Pd',
        atomicNumber: 46,
        atomicMass: 106.42,
        category: 'Transition Metal',
        period: 5,
        group: 10
    },
    {
        image: '/',
        name: 'Silver',
        symbol: 'Ag',
        atomicNumber: 47,
        atomicMass: 107.868,
        category: 'Transition Metal',
        period: 5,
        group: 11
    },
    {
        image: '/',
        name: 'Cadmium',
        symbol: 'Cd',
        atomicNumber: 48,
        atomicMass: 112.414,
        category: 'Transition Metal',
        period: 5,
        group: 12
    },
    {
        image: '/',
        name: 'Indium',
        symbol: 'In',
        atomicNumber: 49,
        atomicMass: 114.818,
        category: 'Post-Transition Metal',
        period: 5,
        group: 13
    },
    {
        image: '/',
        name: 'Tin',
        symbol: 'Sn',
        atomicNumber: 50,
        atomicMass: 118.71,
        category: 'Post-Transition Metal',
        period: 5,
        group: 14
    },
    {
        image: '/',
        name: 'Antimony',
        symbol: 'Sb',
        atomicNumber: 51,
        atomicMass: 121.76,
        category: 'Metalloid',
        period: 5,
        group: 15
    },
    {
        image: '/',
        name: 'Tellurium',
        symbol: 'Te',
        atomicNumber: 52,
        atomicMass: 127.6,
        category: 'Metalloid',
        period: 5,
        group: 16
    },
    {
        image: '/',
        name: 'Iodine',
        symbol: 'I',
        atomicNumber: 53,
        atomicMass: 126.904,
        category: 'Halogen',
        period: 5,
        group: 17
    },
    {
        image: '/',
        name: 'Xenon',
        symbol: 'Xe',
        atomicNumber: 54,
        atomicMass: 131.293,
        category: 'Noble Gas',
        period: 5,
        group: 18
    },
    {
        image: '/',
        name: 'Cesium',
        symbol: 'Cs',
        atomicNumber: 55,
        atomicMass: 132.905,
        category: 'Alkali Metal',
        period: 6,
        group: 1
    },
    {
        image: '/',
        name: 'Barium',
        symbol: 'Ba',
        atomicNumber: 56,
        atomicMass: 137.327,
        category: 'Alkaline Earth Metal',
        period: 6,
        group: 2
    },
    {
        image: '/',
        name: 'Lanthanum',
        symbol: 'La',
        atomicNumber: 57,
        atomicMass: 138.905,
        category: 'Lanthanide',
        period: 6,
        group: 3
    },
    {
        image: '/',
        name: 'Cerium',
        symbol: 'Ce',
        atomicNumber: 58,
        atomicMass: 140.116,
        category: 'Lanthanide',
        period: 6,
        group: 3
    },
    {
        image: '/',
        name: 'Praseodymium',
        symbol: 'Pr',
        atomicNumber: 59,
        atomicMass: 140.908,
        category: 'Lanthanide',
        period: 6,
        group: 3
    },
    {
        image: '/',
        name: 'Neodymium',
        symbol: 'Nd',
        atomicNumber: 60,
        atomicMass: 144.242,
        category: 'Lanthanide',
        period: 6,
        group: 3
    },
    {
        image: '/',
        name: 'Promethium',
        symbol: 'Pm',
        atomicNumber: 61,
        atomicMass: 145,
        category: 'Lanthanide',
        period: 6,
        group: 3
    },
    {
        image: '/',
        name: 'Samarium',
        symbol: 'Sm',
        atomicNumber: 62,
        atomicMass: 150.36,
        category: 'Lanthanide',
        period: 6,
        group: 3
    },
    {
        image: '/',
        name: 'Europium',
        symbol: 'Eu',
        atomicNumber: 63,
        atomicMass: 151.964,
        category: 'Lanthanide',
        period: 6,
        group: 3
    },
    {
        image: '/',
        name: 'Gadolinium',
        symbol: 'Gd',
        atomicNumber: 64,
        atomicMass: 157.25,
        category: 'Lanthanide',
        period: 6,
        group: 3
    },
    {
        image: '/',
        name: 'Terbium',
        symbol: 'Tb',
        atomicNumber: 65,
        atomicMass: 158.925,
        category: 'Lanthanide',
        period: 6,
        group: 3
    },
    {
        image: '/',
        name: 'Dysprosium',
        symbol: 'Dy',
        atomicNumber: 66,
        atomicMass: 162.5,
        category: 'Lanthanide',
        period: 6,
        group: 3
    },
    {
        image: '/',
        name: 'Holmium',
        symbol: 'Ho',
        atomicNumber: 67,
        atomicMass: 164.93,
        category: 'Lanthanide',
        period: 6,
        group: 3
    },
    {
        image: '/',
        name: 'Erbium',
        symbol: 'Er',
        atomicNumber: 68,
        atomicMass: 167.259,
        category: 'Lanthanide',
        period: 6,
        group: 3
    },
    {
        image: '/',
        name: 'Thulium',
        symbol: 'Tm',
        atomicNumber: 69,
        atomicMass: 168.934,
        category: 'Lanthanide',
        period: 6,
        group: 3
    },
    {
        image: '/',
        name: 'Ytterbium',
        symbol: 'Yb',
        atomicNumber: 70,
        atomicMass: 173.045,
        category: 'Lanthanide',
        period: 6,
        group: 3
    },
    {
        image: '/',
        name: 'Lutetium',
        symbol: 'Lu',
        atomicNumber: 71,
        atomicMass: 174.967,
        category: 'Lanthanide',
        period: 6,
        group: 3
    },
    {
        image: '/',
        name: 'Hafnium',
        symbol: 'Hf',
        atomicNumber: 72,
        atomicMass: 178.49,
        category: 'Transition Metal',
        period: 6,
        group: 4
    },
    {
        image: '/',
        name: 'Tantalum',
        symbol: 'Ta',
        atomicNumber: 73,
        atomicMass: 180.948,
        category: 'Transition Metal',
        period: 6,
        group: 5
    },
    {
        image: '/',
        name: 'Tungsten',
        symbol: 'W',
        atomicNumber: 74,
        atomicMass: 183.84,
        category: 'Transition Metal',
        period: 6,
        group: 6
    },
    {
        image: '/',
        name: 'Rhenium',
        symbol: 'Re',
        atomicNumber: 75,
        atomicMass: 186.207,
        category: 'Transition Metal',
        period: 6,
        group: 7
    },
    {
        image: '/',
        name: 'Osmium',
        symbol: 'Os',
        atomicNumber: 76,
        atomicMass: 190.23,
        category: 'Transition Metal',
        period: 6,
        group: 8
    },
    {
        image: '/',
        name: 'Iridium',
        symbol: 'Ir',
        atomicNumber: 77,
        atomicMass: 192.217,
        category: 'Transition Metal',
        period: 6,
        group: 9
    },
    {
        image: '/',
        name: 'Platinum',
        symbol: 'Pt',
        atomicNumber: 78,
        atomicMass: 195.084,
        category: 'Transition Metal',
        period: 6,
        group: 10
    },
    {
        image: '/',
        name: 'Gold',
        symbol: 'Au',
        atomicNumber: 79,
        atomicMass: 196.967,
        category: 'Transition Metal',
        period: 6,
        group: 11
    },
    {
        image: '/',
        name: 'Mercury',
        symbol: 'Hg',
        atomicNumber: 80,
        atomicMass: 200.592,
        category: 'Transition Metal',
        period: 6,
        group: 12
    },
    {
        image: '/',
        name: 'Thallium',
        symbol: 'Tl',
        atomicNumber: 81,
        atomicMass: 204.38,
        category: 'Post-Transition Metal',
        period: 6,
        group: 13
    },
    {
        image: '/',
        name: 'Lead',
        symbol: 'Pb',
        atomicNumber: 82,
        atomicMass: 207.2,
        category: 'Post-Transition Metal',
        period: 6,
        group: 14
    },
    {
        image: '/',
        name: 'Bismuth',
        symbol: 'Bi',
        atomicNumber: 83,
        atomicMass: 208.98,
        category: 'Post-Transition Metal',
        period: 6,
        group: 15
    },
    {
        image: '/',
        name: 'Polonium',
        symbol: 'Po',
        atomicNumber: 84,
        atomicMass: 209,
        category: 'Post-Transition Metal',
        period: 6,
        group: 16
    },
    {
        image: '/',
        name: 'Astatine',
        symbol: 'At',
        atomicNumber: 85,
        atomicMass: 210,
        category: 'Halogen',
        period: 6,
        group: 17
    },
    {
        image: '/',
        name: 'Radon',
        symbol: 'Rn',
        atomicNumber: 86,
        atomicMass: 222,
        category: 'Noble Gas',
        period: 6,
        group: 18
    },
    {
        image: '/',
        name: 'Francium',
        symbol: 'Fr',
        atomicNumber: 87,
        atomicMass: 223,
        category: 'Alkali Metal',
        period: 7,
        group: 1
    },
    {
        image: '/',
        name: 'Radium',
        symbol: 'Ra',
        atomicNumber: 88,
        atomicMass: 226,
        category: 'Alkaline Earth Metal',
        period: 7,
        group: 2
    },
    {
        image: '/',
        name: 'Actinium',
        symbol: 'Ac',
        atomicNumber: 89,
        atomicMass: 227,
        category: 'Actinide',
        period: 7,
        group: 3
    },
    {
        image: '/',
        name: 'Thorium',
        symbol: 'Th',
        atomicNumber: 90,
        atomicMass: 232.038,
        category: 'Actinide',
        period: 7,
        group: 3
    },
    {
        image: '/',
        name: 'Protactinium',
        symbol: 'Pa',
        atomicNumber: 91,
        atomicMass: 231.036,
        category: 'Actinide',
        period: 7,
        group: 3
    },
    {
        image: '/',
        name: 'Uranium',
        symbol: 'U',
        atomicNumber: 92,
        atomicMass: 238.029,
        category: 'Actinide',
        period: 7,
        group: 3
    },
    {
        image: '/',
        name: 'Neptunium',
        symbol: 'Np',
        atomicNumber: 93,
        atomicMass: 237,
        category: 'Actinide',
        period: 7,
        group: 3
    },
    {
        image: '/',
        name: 'Plutonium',
        symbol: 'Pu',
        atomicNumber: 94,
        atomicMass: 244,
        category: 'Actinide',
        period: 7,
        group: 3
    },
    {
        image: '/',
        name: 'Americium',
        symbol: 'Am',
        atomicNumber: 95,
        atomicMass: 243,
        category: 'Actinide',
        period: 7,
        group: 3
    },
    {
        image: '/',
        name: 'Curium',
        symbol: 'Cm',
        atomicNumber: 96,
        atomicMass: 247,
        category: 'Actinide',
        period: 7,
        group: 3
    },
    {
        image: '/',
        name: 'Berkelium',
        symbol: 'Bk',
        atomicNumber: 97,
        atomicMass: 247,
        category: 'Actinide',
        period: 7,
        group: 3
    },
    {
        image: '/',
        name: 'Californium',
        symbol: 'Cf',
        atomicNumber: 98,
        atomicMass: 251,
        category: 'Actinide',
        period: 7,
        group: 3
    },
    {
        image: '/',
        name: 'Einsteinium',
        symbol: 'Es',
        atomicNumber: 99,
        atomicMass: 252,
        category: 'Actinide',
        period: 7,
        group: 3
    },
    {
        image: '/',
        name: 'Fermium',
        symbol: 'Fm',
        atomicNumber: 100,
        atomicMass: 257,
        category: 'Actinide',
        period: 7,
        group: 3
    },
    {
        image: '/',
        name: 'Mendelevium',
        symbol: 'Md',
        atomicNumber: 101,
        atomicMass: 258,
        category: 'Actinide',
        period: 7,
        group: 3
    },
    {
        image: '/',
        name: 'Nobelium',
        symbol: 'No',
        atomicNumber: 102,
        atomicMass: 259,
        category: 'Actinide',
        period: 7,
        group: 3
    },
    {
        image: '/',
        name: 'Lawrencium',
        symbol: 'Lr',
        atomicNumber: 103,
        atomicMass: 262,
        category: 'Actinide',
        period: 7,
        group: 3
    },
    {
        image: '/',
        name: 'Rutherfordium',
        symbol: 'Rf',
        atomicNumber: 104,
        atomicMass: 267,
        category: 'Transition Metal',
        period: 7,
        group: 4
    },
    {
        image: '/',
        name: 'Dubnium',
        symbol: 'Db',
        atomicNumber: 105,
        atomicMass: 270,
        category: 'Transition Metal',
        period: 7,
        group: 5
    },
    {
        image: '/',
        name: 'Seaborgium',
        symbol: 'Sg',
        atomicNumber: 106,
        atomicMass: 271,
        category: 'Transition Metal',
        period: 7,
        group: 6
    },
    {
        image: '/',
        name: 'Bohrium',
        symbol: 'Bh',
        atomicNumber: 107,
        atomicMass: 270,
        category: 'Transition Metal',
        period: 7,
        group: 7
    },
    {
        image: '/',
        name: 'Hassium',
        symbol: 'Hs',
        atomicNumber: 108,
        atomicMass: 277,
        category: 'Transition Metal',
        period: 7,
        group: 8
    },
    {
        image: '/',
        name: 'Meitnerium',
        symbol: 'Mt',
        atomicNumber: 109,
        atomicMass: 276,
        category: 'Unknown',
        period: 7,
        group: 9
    },
    {
        image: '/',
        name: 'Darmstadtium',
        symbol: 'Ds',
        atomicNumber: 110,
        atomicMass: 281,
        category: 'Unknown',
        period: 7,
        group: 10
    },
    {
        image: '/',
        name: 'Roentgenium',
        symbol: 'Rg',
        atomicNumber: 111,
        atomicMass: 280,
        category: 'Unknown',
        period: 7,
        group: 11
    },
    {
        image: '/',
        name: 'Copernicium',
        symbol: 'Cn',
        atomicNumber: 112,
        atomicMass: 285,
        category: 'Transition Metal',
        period: 7,
        group: 12
    },
    {
        image: '/',
        name: 'Nihonium',
        symbol: 'Nh',
        atomicNumber: 113,
        atomicMass: 284,
        category: 'Unknown',
        period: 7,
        group: 13
    },
    {
        image: '/',
        name: 'Flerovium',
        symbol: 'Fl',
        atomicNumber: 114,
        atomicMass: 289,
        category: 'Unknown',
        period: 7,
        group: 14
    },
    {
        image: '/',
        name: 'Moscovium',
        symbol: 'Mc',
        atomicNumber: 115,
        atomicMass: 288,
        category: 'Unknown',
        period: 7,
        group: 15
    },
    {
        image: '/',
        name: 'Livermorium',
        symbol: 'Lv',
        atomicNumber: 116,
        atomicMass: 293,
        category: 'Unknown',
        period: 7,
        group: 16
    },
    {
        image: '/',
        name: 'Tennessine',
        symbol: 'Ts',
        atomicNumber: 117,
        atomicMass: 294,
        category: 'Unknown',
        period: 7,
        group: 17
    },
    {
        image: '/',
        name: 'Oganesson',
        symbol: 'Og',
        atomicNumber: 118,
        atomicMass: 294,
        category: 'Unknown',
        period: 7,
        group: 18
    }
];
function useElementData() {
    const [elements, setElements] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])([]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        setElements(elementData);
    }, []);
    return elements;
}
}}),
"[project]/components/ElementCard.tsx [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "default": (()=>ElementCard)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/image.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/framer-motion/dist/es/render/components/motion/proxy.mjs [app-ssr] (ecmascript)");
;
;
;
const categoryColors = {
    'Alkali Metal': 'bg-red-500',
    'Alkaline Earth Metal': 'bg-orange-400',
    'Transition Metal': 'bg-yellow-300',
    'Post-Transition Metal': 'bg-green-400',
    Metalloid: 'bg-teal-400',
    Nonmetal: 'bg-blue-400',
    Halogen: 'bg-indigo-400',
    'Noble Gas': 'bg-purple-400',
    Lanthanide: 'bg-pink-400',
    Actinide: 'bg-rose-400',
    Unknown: 'bg-gray-400'
};
function ElementCard({ element, isSelected, onClick, style }) {
    const bgColor = categoryColors[element.category] || 'bg-gray-400';
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["motion"].div, {
        layout: true,
        className: `${bgColor} rounded shadow cursor-pointer overflow-hidden`,
        style: style,
        onClick: onClick,
        initial: {
            width: 80,
            height: 80
        },
        animate: {
            width: isSelected ? 500 : 80,
            height: isSelected ? 500 : 80,
            zIndex: isSelected ? 10 : 1
        },
        transition: {
            type: 'spring',
            stiffness: 300,
            damping: 30
        },
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["motion"].div, {
            className: "p-2 gap-5 flex flex-col justify-between",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "text-xs",
                    children: element.atomicNumber
                }, void 0, false, {
                    fileName: "[project]/components/ElementCard.tsx",
                    lineNumber: 49,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["motion"].div, {
                    className: "text-xl font-bold",
                    layout: "position",
                    children: element.symbol
                }, void 0, false, {
                    fileName: "[project]/components/ElementCard.tsx",
                    lineNumber: 50,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["motion"].div, {
                    className: "text-xs truncate",
                    layout: "position",
                    children: element.name
                }, void 0, false, {
                    fileName: "[project]/components/ElementCard.tsx",
                    lineNumber: 53,
                    columnNumber: 9
                }, this),
                isSelected && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["motion"].div, {
                    initial: {
                        opacity: 0
                    },
                    animate: {
                        opacity: 1
                    },
                    exit: {
                        opacity: 0
                    },
                    className: "mt-2",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("strong", {
                                    children: "Atomic Mass:"
                                }, void 0, false, {
                                    fileName: "[project]/components/ElementCard.tsx",
                                    lineNumber: 64,
                                    columnNumber: 15
                                }, this),
                                " ",
                                element.atomicMass
                            ]
                        }, void 0, true, {
                            fileName: "[project]/components/ElementCard.tsx",
                            lineNumber: 63,
                            columnNumber: 13
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("strong", {
                                    children: "Category:"
                                }, void 0, false, {
                                    fileName: "[project]/components/ElementCard.tsx",
                                    lineNumber: 67,
                                    columnNumber: 15
                                }, this),
                                " ",
                                element.category
                            ]
                        }, void 0, true, {
                            fileName: "[project]/components/ElementCard.tsx",
                            lineNumber: 66,
                            columnNumber: 13
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("strong", {
                                    children: "Period:"
                                }, void 0, false, {
                                    fileName: "[project]/components/ElementCard.tsx",
                                    lineNumber: 70,
                                    columnNumber: 15
                                }, this),
                                " ",
                                element.period
                            ]
                        }, void 0, true, {
                            fileName: "[project]/components/ElementCard.tsx",
                            lineNumber: 69,
                            columnNumber: 13
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("strong", {
                                    children: "Group:"
                                }, void 0, false, {
                                    fileName: "[project]/components/ElementCard.tsx",
                                    lineNumber: 73,
                                    columnNumber: 15
                                }, this),
                                " ",
                                element.group
                            ]
                        }, void 0, true, {
                            fileName: "[project]/components/ElementCard.tsx",
                            lineNumber: 72,
                            columnNumber: 13
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "relative w-full h-32",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                src: element.image,
                                alt: `Image of ${element.name}`,
                                layout: "fill",
                                objectFit: "cover",
                                className: "rounded",
                                priority: true
                            }, void 0, false, {
                                fileName: "[project]/components/ElementCard.tsx",
                                lineNumber: 76,
                                columnNumber: 15
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/components/ElementCard.tsx",
                            lineNumber: 75,
                            columnNumber: 13
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                            href: `https://www.youtube.com/results?search_query=${encodeURIComponent(element.name + ' element')}`,
                            target: "_blank",
                            rel: "noopener noreferrer",
                            className: "inline-block bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600 transition-colors",
                            onClick: (e)=>e.stopPropagation(),
                            children: "Learn More"
                        }, void 0, false, {
                            fileName: "[project]/components/ElementCard.tsx",
                            lineNumber: 85,
                            columnNumber: 13
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/components/ElementCard.tsx",
                    lineNumber: 57,
                    columnNumber: 11
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/components/ElementCard.tsx",
            lineNumber: 48,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/components/ElementCard.tsx",
        lineNumber: 35,
        columnNumber: 5
    }, this);
}
}}),
"[project]/components/PeriodicTable.tsx [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "default": (()=>PeriodicTable)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useElementData$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/hooks/useElementData.ts [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ElementCard$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/components/ElementCard.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$components$2f$AnimatePresence$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/framer-motion/dist/es/components/AnimatePresence/index.mjs [app-ssr] (ecmascript)");
'use client';
;
;
;
;
;
function PeriodicTable() {
    const elements = (0, __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useElementData$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useElementData"])();
    const [selectedElement, setSelectedElement] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(null);
    const getGridPosition = (element)=>{
        return {
            gridColumn: element.group,
            gridRow: element.period
        };
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "container mx-auto p-4 overflow-x-auto",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                className: "text-3xl font-bold text-white mb-4",
                children: "Interactive Periodic Table"
            }, void 0, false, {
                fileName: "[project]/components/PeriodicTable.tsx",
                lineNumber: 21,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "grid grid-cols-18 gap-1 w-[1440px]",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$components$2f$AnimatePresence$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["AnimatePresence"], {
                    children: elements.map((element)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ElementCard$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                            element: element,
                            isSelected: selectedElement?.atomicNumber === element.atomicNumber,
                            onClick: ()=>setSelectedElement(selectedElement?.atomicNumber === element.atomicNumber ? null : element),
                            style: getGridPosition(element)
                        }, element.atomicNumber, false, {
                            fileName: "[project]/components/PeriodicTable.tsx",
                            lineNumber: 27,
                            columnNumber: 13
                        }, this))
                }, void 0, false, {
                    fileName: "[project]/components/PeriodicTable.tsx",
                    lineNumber: 25,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/components/PeriodicTable.tsx",
                lineNumber: 24,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/components/PeriodicTable.tsx",
        lineNumber: 20,
        columnNumber: 5
    }, this);
}
}}),
"[project]/app/page.tsx [app-rsc] (ecmascript, Next.js server component, client modules ssr)": ((__turbopack_context__) => {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, t: __turbopack_require_real__ } = __turbopack_context__;
{
}}),

};

//# sourceMappingURL=%5Broot%20of%20the%20server%5D__0c3d70._.js.map